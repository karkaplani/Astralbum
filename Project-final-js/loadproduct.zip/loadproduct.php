<?php
    include_once 'connection.php';

    $products = array();
    $sql = "SELECT * FROM product_info;";
    $result = mysqli_query($conn, $sql);

    while($row = mysqli_fetch_assoc($result)) {
        $products[] = $row; 
    }
    //$products_json = json_encode($products);
?>
<script>
function loadProduct() {
    json_encode($products).forEach(function(product) {
        if (product.id == productID) {
            document.getElementById("albumTitle").innerHTML = product.title;
            document.getElementById("image").src = product.image;
            document.getElementById("info").innerHTML = 'Artist: ' + product.artist +
                '\nGenre : ' + product.genre +
                '\nYear  : ' + product.year +
                '\nRating: ' + product.rateing + '/10';
            document.getElementById("dis").innerHTML = product.description;
            document.getElementById("price").value=product.price;
            document.getElementById("price").innerHTML="Price: $"+product.price;
        }
    });
}
</script>
   



