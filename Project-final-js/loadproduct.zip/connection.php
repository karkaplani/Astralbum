<?php
//This file is to connect the webpage to the database.

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "astralbum11";
$dbName = "astralbum";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>
